
  Mini.PS2.begin();

  Mini.PS2.polling();
        bool L1, R1, L2, R2, L3, R3, SELECT, START;
        bool UP, RIGHT, DOWN, LEFT, TRIANGLE, CIRCLE, CROSS, SQUARE;
        uint8_t RX, RY, LX, LY;
