

  Mini.begin(float vbat, bool _enUART, long buad);
